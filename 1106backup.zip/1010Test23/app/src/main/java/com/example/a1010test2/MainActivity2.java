package com.example.a1010test2;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity2 extends AppCompatActivity {

    ImageButton IB1;
    EditText ET1, username;
    Dialog loginDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        IB1 = (ImageButton) findViewById(R.id.IB1);
        ET1 = (EditText) findViewById(R.id.ET1);
        registerForContextMenu(IB1);
        Intent intent = getIntent();
        String userID = intent.getStringExtra("userID");
        ET1.setText(userID);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.login:
                open(ET1);
                return true;
            case R.id.login2:
                open2(ET1);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.mymenu, menu);
        return true;
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,
                                    ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.setHeaderTitle("카테고리");
        menu.add(0, 1, 0, "한식");
        menu.add(0, 2, 0, "중식");
        menu.add(0, 3, 0, "양식");
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case 1:
                Toast.makeText(this, "한식", Toast.LENGTH_SHORT).show();
                return true;
            case 2:
                Toast.makeText(this, "중식", Toast.LENGTH_SHORT).show();
                return true;
            case 3:
                Toast.makeText(this, "양식", Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }

    public void open(View view) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setTitle("로그인 확인");
        alertDialogBuilder.setMessage("로그인하시겠습니까?");
        alertDialogBuilder.setPositiveButton("yes",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(MainActivity2.this, "로그인이 완료되었습니다.",
                                Toast.LENGTH_LONG).show();
                        ET1.setText("로그인 완료");
                    }
                });
        alertDialogBuilder.setNegativeButton("No",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(MainActivity2.this, "로그인 취소되었습니다.",
                                Toast.LENGTH_LONG).show();
                        //finish(); // Activity 종료 -> 아예 종료된다.
                    }
                });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }
    public void open2(View view) {
        Log.i("Custom", "onClickButton");
        loginDialog = new Dialog(this);
        loginDialog.setContentView(R.layout.custom_dialog);
        loginDialog.setTitle("로그인 화면");
        Button login = (Button)loginDialog.findViewById(R.id.login);
        Button cancel = (Button)loginDialog.findViewById(R.id.cancel);
        username = (EditText)loginDialog.findViewById(R.id.username);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String strUserName = username.getText().toString().trim();
                if(strUserName.length() > 0) {
                    Toast.makeText(getApplicationContext(), "로그인 성공",
                            Toast.LENGTH_LONG).show();
                    ET1.setText(username.getText().toString());
                    loginDialog.dismiss(); // Cancel 버튼을 누르면 다이얼로그가 사라짐
                }
            }
        });
        cancel.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                loginDialog.dismiss(); // Cancel 버튼을 누르면 다이얼로그가 사라짐
            }
        });
        loginDialog.show();
    }


}

